// bu o'zimmizi jo'skiy disklar bilan ishlaydi

DriveInfo[] haydovchiDisklar = DriveInfo.GetDrives();

foreach (DriveInfo drive in haydovchiDisklar)
{
    Console.WriteLine("Haydovchi disk: " + drive.Name);
    Console.WriteLine("Turi: " + drive.DriveType);
    Console.WriteLine("Bo'sh joy miqdori: " + drive.TotalFreeSpace);
    Console.WriteLine("Umumiy miqdori: " + drive.TotalSize);
    Console.WriteLine("Fayl tizimi: " + drive.DriveFormat);
    Console.WriteLine();
}