string papkaNom = @"C:\Test";
DirectoryInfo papka = new DirectoryInfo(papkaNom);

if (!papka.Exists)
{
    papka.Create();
}

FileInfo[] fayllar = papka.GetFiles();
DirectoryInfo[] direktoriyalarniOlish = papka.GetDirectories();

foreach (FileInfo fayl in fayllar)
{
    Console.WriteLine("Fayl: " + fayl.Name);
}

foreach (DirectoryInfo direktoriya in direktoriyalarniOlish)
{
    Console.WriteLine("Direktoriya: " + direktoriya.Name);
}