string faylNom = "test.txt";
using (StreamReader reader = new StreamReader(faylNom))
{
    string qator;
    while ((qator = reader.ReadLine()) != null)
    {
        Console.WriteLine(qator);
    }
}