string faylNom = "test.txt";
string matn = "Bu faylga yozilgan matn.";
File.WriteAllText(faylNom, matn);