string faylNom = "test.txt";
FileInfo fileInfo = new FileInfo(faylNom);

string matn = "Bu fayl test uchun yaratilgan.";
File.WriteAllText(fileInfo.FullName, matn);

bool mavjudmi = fileInfo.Exists;
Console.WriteLine($"Fayl mavjudligi: {mavjudmi}");

string oqibOlish = File.ReadAllText(fileInfo.FullName);
Console.WriteLine($"Fayldagi matn: {oqibOlish}");

fileInfo.Delete();