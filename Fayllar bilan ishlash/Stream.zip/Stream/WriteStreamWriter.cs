string faylNom = "test.txt";
string matn = "Bu faylga yozilgan matn.";

using (StreamWriter writer = new StreamWriter(faylNom))
{
    writer.Write(matn);
}


// 2 - step
string faylNom = "test.txt";
using (StreamWriter writer = new StreamWriter(faylNom))
{
    writer.WriteLine("Bu faylga yozilgan birinchi qator.");
    writer.WriteLine("Bu esa ikkinchi qator.");
}