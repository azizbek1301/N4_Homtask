string faylNom = "test.txt";
using (FileStream fileStream = new FileStream(faylNom, FileMode.Create))
{
    string matn = "Bu FileStream orqali yozilgan matn.";
    byte[] matnBytes = Encoding.UTF8.GetBytes(matn);
    fileStream.Write(matnBytes, 0, matnBytes.Length);
}


// o'qib olish

string faylNom = "test.txt";
using (FileStream fileStream = new FileStream(faylNom, FileMode.Open))
using (StreamReader reader = new StreamReader(fileStream))
{
    string matn = reader.ReadToEnd();
    Console.WriteLine(matn);
}