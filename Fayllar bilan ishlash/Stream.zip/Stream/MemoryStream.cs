using (MemoryStream memoryStream = new MemoryStream())
{
    string matn = "Bu MemoryStream orqali yozilgan matn.";
    byte[] matnBytes = Encoding.UTF8.GetBytes(matn);
    memoryStream.Write(matnBytes, 0, matnBytes.Length);

    memoryStream.Position = 0;

    byte[] oqibOlishBytes = new byte[memoryStream.Length];
    memoryStream.Read(oqibOlishBytes, 0, oqibOlishBytes.Length);

    string oqibOlishMatn = Encoding.UTF8.GetString(oqibOlishBytes);
    Console.WriteLine(oqibOlishMatn);
}