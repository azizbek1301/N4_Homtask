string faylNom = "test.txt";
string matn = "Bu fayl test uchun yaratilgan.";
File.WriteAllText(faylNom, matn);

bool mavjudmi = File.Exists(faylNom);
Console.WriteLine($"Fayl mavjudligi: {mavjudmi}");

string oqibOlish = File.ReadAllText(faylNom);
Console.WriteLine($"Fayldagi matn: {oqibOlish}");

File.Delete(faylNom);