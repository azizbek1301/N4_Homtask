string yangiPapka = @"C:\Test";
Directory.CreateDirectory(yangiPapka);

string[] fayllar = Directory.GetFiles(yangiPapka);
string[] direktoriyalar = Directory.GetDirectories(yangiPapka);

foreach (string fayl in fayllar)
{
    Console.WriteLine("Fayl: " + fayl);
}

foreach (string direktoriya in direktoriyalar)
{
    Console.WriteLine("Direktoriya: " + direktoriya);
}